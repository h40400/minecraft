#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;

#ifndef NO_OVERLAY
uniform sampler2D Sampler1;
#endif

#ifndef EMISSIVE
uniform sampler2D Sampler2;
#endif

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
out vec4 vertexPerFaceColorBack;
out vec4 vertexPerFaceColorFront;
#else
out vec4 vertexColor;
#endif

#ifndef EMISSIVE
out vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
out vec4 overlayColor;
#endif

out vec2 texCoord0;

// --- cs16 skinned first-person arms ---
// two opposite corners of the quad (w = 1 on that corner only, so xyz / w after interpolation is the corner)
out vec4 cs16Corner0;
out vec4 cs16Corner1;
out vec3 cs16CornerUv0;
out vec3 cs16CornerUv1;
// --- end cs16 ---

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif

#ifndef EMISSIVE
    lightMapColor = sample_lightmap(Sampler2, UV2);
#endif

#ifndef NO_OVERLAY
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;

#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

    // --- cs16 skinned first-person arms ---
    cs16Corner0 = cs16Corner1 = vec4(0.0);
    cs16CornerUv0 = cs16CornerUv1 = vec3(0.0);
    if (ProjMat[2][3] != 0.0 && textureSize(Sampler0, 0) == ivec2(64, 64)) {
        // a quad is 4 consecutive vertices, so the IDs = 0 and = 2 (mod 4) in it are opposite corners, whatever
        // base vertex the draw starts at
        int vertex = gl_VertexID % 4;
        if (vertex == 0) {
            cs16Corner0 = vec4(Position, 1.0);
            cs16CornerUv0 = vec3(UV0, 1.0);
        }
        if (vertex == 2) {
            cs16Corner1 = vec4(Position, 1.0);
            cs16CornerUv1 = vec3(UV0, 1.0);
        }
    }
    // --- end cs16 ---
}
