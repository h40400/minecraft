#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

const vec3 CS16_PIVOT = vec3(0.0, -0.25, -0.6);
const float CS16_W = 0.4;
const float CS16_D = 0.2;
const float CS16_MARKER = 254.0;

// a quad corner touches four texels: one of them belongs to the face itself
bool cs16Marked() {
    ivec2 size = textureSize(Sampler0, 0);
    ivec2 base = ivec2(round(UV0 * vec2(size)));
    for (int i = 0; i < 4; i++) {
        ivec2 p = clamp(base - ivec2(i & 1, i >> 1), ivec2(0), size - 1);
        if (abs(texelFetch(Sampler0, p, 0).a * 255.0 - CS16_MARKER) < 0.5) return true;
    }
    return false;
}

float cs16Value(int nibble, float amp) {
    float q = float(nibble - 8) / 7.0;
    return sign(q) * q * q * amp;
}

vec3 cs16Rotate(vec3 v, vec3 w) {
    float a = length(w);
    if (a < 1e-6) return v;
    vec3 k = w / a;
    return v * cos(a) + cross(k, v) * sin(a) + k * dot(k, v) * (1.0 - cos(a));
}

void main() {
    vec3 pos = Position;
    vec3 normal = Normal;
    vec4 color = Color;
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    if (c != ivec3(255) && cs16Marked()) {
        vec3 w = vec3(cs16Value(c.r >> 4, CS16_W), cs16Value(c.r & 15, CS16_W), cs16Value(c.g >> 4, CS16_W));
        vec3 d = vec3(cs16Value(c.g & 15, CS16_D), cs16Value(c.b >> 4, CS16_D), cs16Value(c.b & 15, CS16_D));
        float t = fract(GameTime * 24000.0);
        pos = CS16_PIVOT + cs16Rotate(Position - CS16_PIVOT, w * t) + d * t;
        normal = cs16Rotate(Normal, w * t);
        color = vec4(1.0);
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);

    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, normal, color) * sample_lightmap(Sampler2, UV2);

    texCoord0 = UV0;
}
