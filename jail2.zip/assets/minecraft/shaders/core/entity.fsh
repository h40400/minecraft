#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
in vec4 vertexPerFaceColorBack;
in vec4 vertexPerFaceColorFront;
#else
in vec4 vertexColor;
#endif

#ifndef EMISSIVE
in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
in vec4 overlayColor;
#endif

in vec2 texCoord0;

// --- cs16 skinned first-person arms ---
in vec4 cs16Corner0;
in vec4 cs16Corner1;
in vec3 cs16CornerUv0;
in vec3 cs16CornerUv1;

const ivec4 cs16ArmUVs[] = ivec4[](
    ivec4(40, 52, 36, 64), // Front
    ivec4(44, 64, 48, 52), // Back
    ivec4(36, 64, 32, 52), // Outer Side
    ivec4(44, 52, 40, 48), // Bottom
    ivec4(40, 52, 44, 64), // Inner Side
    ivec4(36, 52, 40, 48)  // Top
);
const ivec4 cs16SlimArmUVs[] = ivec4[](
    ivec4(39, 52, 36, 64),
    ivec4(43, 64, 46, 52),
    ivec4(36, 64, 32, 52),
    ivec4(42, 52, 39, 48),
    ivec4(39, 52, 43, 64),
    ivec4(36, 52, 39, 48)
);
const bool cs16RotateUV[] = bool[](false, false, true, false, true, false);

vec2 cs16CornerUV(ivec4 d, int vertex, bool rotate) {
    ivec2 uv;
    switch (vertex) {
        case 0: uv = d.xy; break;
        case 1: uv = rotate ? d.xw : d.zy; break;
        case 2: uv = d.zw; break;
        default: uv = rotate ? d.zy : d.xw; break;
    }
    return vec2(uv) / 64.0;
}

bool cs16IsSlim() {
    vec4 a = texture(Sampler0, vec2(54.0 / 64.0, 20.0 / 64.0));
    vec4 b = texture(Sampler0, vec2(55.0 / 64.0, 20.0 / 64.0));
    return a.a == 0.0 || (((a.r + a.g + a.b) == 0.0) && ((b.r + b.g + b.b) == 0.0) && a.a == 1.0 && b.a == 1.0);
}
// the skull's faces on the skin (ModelPart.Cube order DOWN, UP, WEST, NORTH, EAST, SOUTH; 8x8x8 at texOffs 0,0, hat
// layer at 32,0) as the polygon's (u1, v1, u2, v2): its vertices get (u2,v1), (u1,v1), (u1,v2), (u2,v2)
const ivec4 cs16HeadRects[] = ivec4[](
    ivec4(8, 0, 16, 8),
    ivec4(16, 8, 24, 0),
    ivec4(0, 8, 8, 16),
    ivec4(8, 8, 16, 16),
    ivec4(16, 8, 24, 16),
    ivec4(24, 8, 32, 16)
);

// the arm-region UV for this fragment: the face comes from the quad's centre (unambiguous, corners are shared),
// the position in the face from this fragment's UV; offset moves the arm region (sleeve, right arm)
vec2 cs16ArmUV(vec2 uv, vec2 centre, ivec2 offset) {
    vec2 c = centre * 64.0;
    if (c.x >= 32.0) c.x -= 32.0;
    int face = c.y < 8.0 ? (c.x < 16.0 ? 0 : 1) : 2 + clamp(int(c.x / 8.0), 0, 3);
    ivec4 r = cs16HeadRects[face];
    vec2 p = uv * 64.0;
    if (p.x >= 32.0) p.x -= 32.0;
    vec2 st = clamp((p - vec2(r.xy)) / vec2(r.zw - r.xy), 0.0, 1.0);
    ivec4 base = (cs16IsSlim() ? cs16SlimArmUVs[face] : cs16ArmUVs[face]) + ivec4(offset, offset);
    bool rot = cs16RotateUV[face];
    // corner k of the polygon sits at (s,t): 0 = (1,0), 1 = (0,0), 2 = (0,1), 3 = (1,1)
    vec2 top = mix(cs16CornerUV(base, 1, rot), cs16CornerUV(base, 0, rot), st.x);
    vec2 bottom = mix(cs16CornerUV(base, 2, rot), cs16CornerUV(base, 3, rot), st.x);
    return mix(top, bottom, st.y);
}

const vec3 CS16_SCALE_L = vec3(0.208000, 0.208000, 0.832000);
const vec3 CS16_SCALE_R = vec3(0.210080, 0.210080, 0.840320);

vec3 cs16Diagonals(vec3 halfSize) {
    return vec3(length(halfSize.xz), length(halfSize.yz), length(halfSize.xy));
}

bool cs16Match(float h, vec3 r) {
    return abs(h - r.x) < 0.0004 || abs(h - r.y) < 0.0004 || abs(h - r.z) < 0.0004;
}

// Fallback for the sleeve (hat) layer when a client mod rebuilt the skull with a slightly different inflation
// (Entity Model Features & co.): a quad that samples the skin's hat area and is 0.98-1.15x the size of an arm
// skull face is still an arm sleeve - never the player's head texture. Returns 0 = no, 1 = left, 2 = right.
int cs16HatFallback(float h) {
    vec3 d = cs16Diagonals(0.5 * CS16_SCALE_L);
    float hatL = 1.0625, hatR = 1.0625 * CS16_SCALE_R.x / CS16_SCALE_L.x;
    for (int i = 0; i < 3; i++) {
        float r = h / d[i];
        if (r > 0.98 && r < 1.15) return abs(r - hatL) <= abs(r - hatR) ? 1 : 2;
    }
    return 0;
}
// --- end cs16 ---

out vec4 fragColor;

void main() {
    vec2 uv = texCoord0;
    if (cs16Corner0.w != 0.0 && cs16Corner1.w != 0.0 && cs16CornerUv0.z != 0.0 && cs16CornerUv1.z != 0.0) {
        float h = length(cs16Corner0.xyz / cs16Corner0.w - cs16Corner1.xyz / cs16Corner1.w);
        vec2 centre = 0.5 * (cs16CornerUv0.xy / cs16CornerUv0.z + cs16CornerUv1.xy / cs16CornerUv1.z);
        // arm regions: left arm 32,48 (sleeve +16,0), right arm 40,16 (sleeve +0,16)
        const ivec2 LEFT = ivec2(0), LEFT_HAT = ivec2(16, 0), RIGHT = ivec2(8, -32), RIGHT_HAT = ivec2(8, -16);
        // skull cube edge = 0.5 * scale (head layer), hat layer is inflated by 0.25 px
        if (cs16Match(h, cs16Diagonals(0.5 * CS16_SCALE_L))) uv = cs16ArmUV(texCoord0, centre, LEFT);
        else if (cs16Match(h, cs16Diagonals(0.53125 * CS16_SCALE_L))) uv = cs16ArmUV(texCoord0, centre, LEFT_HAT);
        else if (cs16Match(h, cs16Diagonals(0.5 * CS16_SCALE_R))) uv = cs16ArmUV(texCoord0, centre, RIGHT);
        else if (cs16Match(h, cs16Diagonals(0.53125 * CS16_SCALE_R))) uv = cs16ArmUV(texCoord0, centre, RIGHT_HAT);
        else if (texCoord0.x >= 0.5 && texCoord0.y < 0.25) {
            int side = cs16HatFallback(h);
            if (side == 1) uv = cs16ArmUV(texCoord0, centre, LEFT_HAT);
            else if (side == 2) uv = cs16ArmUV(texCoord0, centre, RIGHT_HAT);
        }
    }

    vec4 color = texture(Sampler0, uv);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

#ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
#else
    vec4 faceVertexColor = vertexColor;
#endif

#ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, uv).a) {
        discard;
    }
    faceVertexColor.a = 1.0;
#endif

    color *= faceVertexColor * ColorModulator;
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
#ifndef EMISSIVE
    color *= lightMapColor;
#endif

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
